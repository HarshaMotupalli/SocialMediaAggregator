// JavaScript for home.html

document.addEventListener("DOMContentLoaded", () => {
  const publishButton = document.getElementById("publish-button")
  const postContent = document.getElementById("post-content")

  publishButton.addEventListener("click", () => {
    const content = postContent.value
    if (content.trim() !== "") {
      alert("Post published: " + content)
      postContent.value = ""
    } else {
      alert("Please enter some content before publishing.")
    }
  })

  // Placeholder for performance chart
  const performanceChart = document.getElementById("performance-chart")
  performanceChart.textContent = "Performance Chart Placeholder"

  // Placeholder for content calendar
  const contentCalendar = document.getElementById("content-calendar")
  contentCalendar.textContent = "Content Calendar Placeholder"
})

