import React from 'react';
import { Link } from 'react-router-dom';
import { Share2, Twitter, Facebook, Instagram, Linkedin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center">
              <Share2 className="h-8 w-8 text-indigo-400" />
              <span className="ml-2 text-xl font-bold">SocialHub</span>
            </div>
            <p className="text-gray-400 text-sm">
              Simplify your social media management with our powerful platform.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider">Quick Links</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link to="/home" className="text-gray-400 hover:text-white">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/blog" className="text-gray-400 hover:text-white">
                  Blog
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-400 hover:text-white">
                  About
                </Link>
              </li>
            </ul>
          </div>

          {/* Features */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider">Features</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link to="/features/publish" className="text-gray-400 hover:text-white">
                  Publish
                </Link>
              </li>
              <li>
                <Link to="/features/analyze" className="text-gray-400 hover:text-white">
                  Analyze
                </Link>
              </li>
              <li>
                <Link to="/features/schedule" className="text-gray-400 hover:text-white">
                  Schedule
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider">Contact</h3>
            <ul className="mt-4 space-y-2">
              <li className="text-gray-400">
                Email: support@socialhub.com
              </li>
              <li className="text-gray-400">
                Phone: (555) 123-4567
              </li>
              <li className="text-gray-400">
                Address: 123 Social Street
                <br />
                Digital City, DC 12345
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-700">
          <p className="text-gray-400 text-sm text-center">
            © {new Date().getFullYear()} SocialHub. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;