document.addEventListener("DOMContentLoaded", () => {
  const billingToggle = document.getElementById("billing-toggle")
  const priceElements = document.querySelectorAll(".price")
  const monthlyPrices = ["$29", "$79"]
  const yearlyPrices = ["$279", "$759"]

  billingToggle.addEventListener("change", () => {
    const isYearly = billingToggle.checked
    priceElements.forEach((element, index) => {
      if (element.textContent !== "Custom") {
        const price = isYearly ? yearlyPrices[index] : monthlyPrices[index]
        const period = isYearly ? "/year" : "/month"
        element.innerHTML = `${price}<span>${period}</span>`
      }
    })
  })

  // Add hover effect to pricing items
  const pricingItems = document.querySelectorAll(".pricing-item")
  pricingItems.forEach((item) => {
    item.addEventListener("mouseenter", () => {
      if (!item.classList.contains("popular")) {
        item.style.backgroundColor = "#e8e8e8"
      }
    })
    item.addEventListener("mouseleave", () => {
      if (!item.classList.contains("popular")) {
        item.style.backgroundColor = "#f8f8f8"
      }
    })
  })

  // Smooth scroll to FAQ section
  const faqLink = document.createElement("a")
  faqLink.href = "#faq"
  faqLink.textContent = "Frequently Asked Questions"
  faqLink.classList.add("faq-link")
  document.querySelector(".pricing-grid").after(faqLink)

  faqLink.addEventListener("click", (e) => {
    e.preventDefault()
    document.querySelector(".faq").scrollIntoView({
      behavior: "smooth",
    })
  })
})

