// JavaScript for index.html
console.log("Welcome to Bolt AI")

