// JavaScript for about.html
console.log("About Bolt AI")

