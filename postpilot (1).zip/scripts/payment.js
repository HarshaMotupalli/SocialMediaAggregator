document.addEventListener("DOMContentLoaded", () => {
  const urlParams = new URLSearchParams(window.location.search)
  const plan = urlParams.get("plan")
  const planInput = document.getElementById("plan")

  if (plan) {
    planInput.value = plan.charAt(0).toUpperCase() + plan.slice(1)
  } else {
    planInput.value = "Unknown"
  }

  const paymentForm = document.getElementById("payment-form")
  paymentForm.addEventListener("submit", (e) => {
    e.preventDefault()
    // Here you would typically send the form data to your server for processing
    // For this example, we'll just show an alert
    alert("Payment processed successfully!")
    window.location.href = "index.html"
  })

  // Basic form validation
  const cardNumber = document.getElementById("card-number")
  const expiry = document.getElementById("expiry")
  const cvv = document.getElementById("cvv")

  cardNumber.addEventListener("input", (e) => {
    e.target.value = e.target.value.replace(/\D/g, "").slice(0, 16)
  })

  expiry.addEventListener("input", (e) => {
    e.target.value = e.target.value.replace(/\D/g, "").slice(0, 4)
    if (e.target.value.length > 2) {
      e.target.value = e.target.value.slice(0, 2) + "/" + e.target.value.slice(2)
    }
  })

  cvv.addEventListener("input", (e) => {
    e.target.value = e.target.value.replace(/\D/g, "").slice(0, 3)
  })
})

