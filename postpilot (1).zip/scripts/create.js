document.addEventListener("DOMContentLoaded", () => {
  // Animate feature items on scroll
  const featureItems = document.querySelectorAll(".feature-item")
  const observerOptions = {
    root: null,
    rootMargin: "0px",
    threshold: 0.1,
  }

  const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = 1
        entry.target.style.transform = "translateY(0)"
        observer.unobserve(entry.target)
      }
    })
  }, observerOptions)

  featureItems.forEach((item) => {
    item.style.opacity = 0
    item.style.transform = "translateY(20px)"
    observer.observe(item)
  })

  // Make idea cards draggable
  const ideaCards = document.querySelectorAll(".idea-card")
  ideaCards.forEach((card) => {
    card.addEventListener("dragstart", dragStart)
    card.addEventListener("dragend", dragEnd)
    card.setAttribute("draggable", true)
  })

  function dragStart(e) {
    e.target.style.opacity = "0.5"
  }

  function dragEnd(e) {
    e.target.style.opacity = "1"
  }

  // Animate hashtags
  const hashtags = document.querySelectorAll(".hashtag")
  hashtags.forEach((hashtag) => {
    hashtag.addEventListener("mouseover", () => {
      hashtag.style.transform = "scale(1.1)"
    })
    hashtag.addEventListener("mouseout", () => {
      hashtag.style.transform = "scale(1)"
    })
  })
})

