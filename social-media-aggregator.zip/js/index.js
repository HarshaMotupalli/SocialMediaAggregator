// Functionality specific to the index page
document.addEventListener("DOMContentLoaded", () => {
  console.log("Index page loaded")
  // Add any index-specific functionality here
})

