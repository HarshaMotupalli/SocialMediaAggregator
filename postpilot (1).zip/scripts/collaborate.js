document.addEventListener("DOMContentLoaded", () => {
  // Make task cards draggable
  const taskCards = document.querySelectorAll(".task-card")
  const taskColumns = document.querySelectorAll(".task-column")

  taskCards.forEach((card) => {
    card.addEventListener("dragstart", dragStart)
    card.addEventListener("dragend", dragEnd)
  })

  taskColumns.forEach((column) => {
    column.addEventListener("dragover", dragOver)
    column.addEventListener("dragenter", dragEnter)
    column.addEventListener("dragleave", dragLeave)
    column.addEventListener("drop", drop)
  })

  function dragStart() {
    this.classList.add("dragging")
  }

  function dragEnd() {
    this.classList.remove("dragging")
  }

  function dragOver(e) {
    e.preventDefault()
  }

  function dragEnter(e) {
    e.preventDefault()
    this.classList.add("drag-over")
  }

  function dragLeave() {
    this.classList.remove("drag-over")
  }

  function drop() {
    this.classList.remove("drag-over")
    const card = document.querySelector(".dragging")
    this.appendChild(card)
  }

  // Simulate chat functionality
  const chatInput = document.querySelector(".chat-input input")
  const chatSendButton = document.querySelector(".chat-input button")
  const chatWindow = document.querySelector(".chat-window")

  chatSendButton.addEventListener("click", sendMessage)
  chatInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      sendMessage()
    }
  })

  function sendMessage() {
    const message = chatInput.value.trim()
    if (message) {
      const messageElement = document.createElement("div")
      messageElement.classList.add("chat-message")
      messageElement.innerHTML = `<span class="user">You:</span> ${message}`
      chatWindow.insertBefore(messageElement, chatWindow.lastElementChild)
      chatInput.value = ""
    }
  }

  // Animate feature items on scroll
  const featureItems = document.querySelectorAll(".feature-item")
  const observerOptions = {
    root: null,
    rootMargin: "0px",
    threshold: 0.1,
  }

  const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = 1
        entry.target.style.transform = "translateX(0)"
        observer.unobserve(entry.target)
      }
    })
  }, observerOptions)

  featureItems.forEach((item) => {
    item.style.opacity = 0
    item.style.transform = "translateX(20px)"
    observer.observe(item)
  })
})

