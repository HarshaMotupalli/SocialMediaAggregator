document.addEventListener("DOMContentLoaded", () => {
  // Highlight the current feature section based on URL hash
  const highlightCurrentSection = () => {
    const hash = window.location.hash
    if (hash) {
      document.querySelectorAll(".feature-section").forEach((section) => {
        section.classList.remove("active")
      })
      const currentSection = document.querySelector(hash)
      if (currentSection) {
        currentSection.classList.add("active")
      }
    }
  }

  highlightCurrentSection()
  window.addEventListener("hashchange", highlightCurrentSection)

  // Add smooth scrolling to feature sections
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()
      document.querySelector(this.getAttribute("href")).scrollIntoView({
        behavior: "smooth",
      })
    })
  })
})

