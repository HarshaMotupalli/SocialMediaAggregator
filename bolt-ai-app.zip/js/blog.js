// JavaScript for blog.html

const blogPosts = [
  {
    title: "Top 10 Social Media Trends for 2023",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit...",
  },
  {
    title: "How to Increase Your Social Media Engagement",
    content: "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua...",
  },
  {
    title: "The Importance of Consistent Branding Across Platforms",
    content: "Ut enim ad minim veniam, quis nostrud exercitation ullamco...",
  },
]

document.addEventListener("DOMContentLoaded", () => {
  const blogPostsContainer = document.getElementById("blog-posts")

  blogPosts.forEach((post) => {
    const postElement = document.createElement("article")
    postElement.classList.add("blog-post")
    postElement.innerHTML = `
            <h2>${post.title}</h2>
            <p>${post.content}</p>
            <a href="#" class="read-more">Read More</a>
        `
    blogPostsContainer.appendChild(postElement)
  })
})

