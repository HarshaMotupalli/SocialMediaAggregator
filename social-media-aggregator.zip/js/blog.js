// Functionality specific to the blog page
document.addEventListener("DOMContentLoaded", () => {
  console.log("Blog page loaded")

  // Simulated blog posts data
  const blogPosts = [
    { title: "Top 10 Social Media Trends for 2025", date: "2025-01-15", content: "Lorem ipsum dolor sit amet..." },
    {
      title: "How to Increase Your Social Media Engagement",
      date: "2025-01-10",
      content: "Consectetur adipiscing elit...",
    },
    {
      title: "The Importance of Analytics in Social Media Marketing",
      date: "2025-01-05",
      content: "Sed do eiusmod tempor incididunt...",
    },
  ]

  const blogPostsContainer = document.getElementById("blog-posts")

  // Render blog posts
  blogPosts.forEach((post) => {
    const postElement = document.createElement("article")
    postElement.classList.add("blog-post")
    postElement.innerHTML = `
            <h2>${post.title}</h2>
            <p class="date">${post.date}</p>
            <p>${post.content}</p>
        `
    blogPostsContainer.appendChild(postElement)
  })
})

