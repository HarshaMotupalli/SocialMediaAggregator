// Functionality specific to the features page
document.addEventListener("DOMContentLoaded", () => {
  console.log("Features page loaded")
  // Add any features-specific functionality here
})

