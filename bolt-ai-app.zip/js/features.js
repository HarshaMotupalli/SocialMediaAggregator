console.log("Features page loaded")

