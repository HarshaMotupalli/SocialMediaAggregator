// Common JavaScript for all pages

// Function to load header
function loadHeader() {
  const header = document.getElementById("header")
  header.innerHTML = `
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="home.html">Dashboard</a></li>
                <li><a href="features.html">Features</a></li>
                <li><a href="blog.html">Blog</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="login.html">Login</a></li>
                <li><a href="register.html">Register</a></li>
            </ul>
        </nav>
    `
}

// Function to load footer
function loadFooter() {
  const footer = document.getElementById("footer")
  footer.innerHTML = `
        <p>&copy; 2023 Bolt AI. All rights reserved.</p>
    `
}

// Load header and footer when the DOM is fully loaded
document.addEventListener("DOMContentLoaded", () => {
  loadHeader()
  loadFooter()
})

