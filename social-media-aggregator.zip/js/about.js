// Functionality specific to the about page
document.addEventListener("DOMContentLoaded", () => {
  console.log("About page loaded")
  // Add any about-specific functionality here
})

