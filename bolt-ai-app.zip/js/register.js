document.addEventListener("DOMContentLoaded", () => {
  const registerForm = document.getElementById("register-form")

  registerForm.addEventListener("submit", (e) => {
    e.preventDefault()
    const name = document.getElementById("name").value
    const email = document.getElementById("email").value
    const password = document.getElementById("password").value
    const confirmPassword = document.getElementById("confirm-password").value

    if (password !== confirmPassword) {
      alert("Passwords do not match!")
      return
    }

    // Here you would typically send a request to your server to register the user
    console.log("Registration attempt:", { name, email, password })
    alert("Registration functionality would be implemented here.")
  })
})

