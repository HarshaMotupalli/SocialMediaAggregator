import { Chart } from "@/components/ui/chart"
document.addEventListener("DOMContentLoaded", () => {
  // Cross-Platform Analytics Chart
  const crossPlatformCtx = document.getElementById("crossPlatformChart").getContext("2d")
  new Chart(crossPlatformCtx, {
    type: "bar",
    data: {
      labels: ["Facebook", "Instagram", "Twitter", "LinkedIn"],
      datasets: [
        {
          label: "Followers",
          data: [5000, 7500, 3000, 2000],
          backgroundColor: "rgba(0, 123, 255, 0.5)",
          borderColor: "rgba(0, 123, 255, 1)",
          borderWidth: 1,
        },
        {
          label: "Engagement Rate",
          data: [2.5, 3.8, 1.9, 4.2],
          backgroundColor: "rgba(40, 167, 69, 0.5)",
          borderColor: "rgba(40, 167, 69, 1)",
          borderWidth: 1,
        },
      ],
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  })

  // Engagement Metrics Chart
  const engagementCtx = document.getElementById("engagementChart").getContext("2d")
  new Chart(engagementCtx, {
    type: "line",
    data: {
      labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
      datasets: [
        {
          label: "Likes",
          data: [1200, 1900, 3000, 5000, 4000, 3000],
          borderColor: "rgba(255, 99, 132, 1)",
          tension: 0.1,
        },
        {
          label: "Comments",
          data: [200, 400, 700, 1000, 800, 600],
          borderColor: "rgba(54, 162, 235, 1)",
          tension: 0.1,
        },
        {
          label: "Shares",
          data: [50, 100, 200, 400, 300, 250],
          borderColor: "rgba(255, 206, 86, 1)",
          tension: 0.1,
        },
      ],
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  })

  // Competitor Analysis Chart
  const competitorCtx = document.getElementById("competitorChart").getContext("2d")
  new Chart(competitorCtx, {
    type: "radar",
    data: {
      labels: ["Followers", "Engagement", "Post Frequency", "Response Time", "Brand Mentions"],
      datasets: [
        {
          label: "Your Brand",
          data: [80, 90, 70, 85, 75],
          backgroundColor: "rgba(0, 123, 255, 0.2)",
          borderColor: "rgba(0, 123, 255, 1)",
          pointBackgroundColor: "rgba(0, 123, 255, 1)",
        },
        {
          label: "Competitor A",
          data: [90, 80, 85, 70, 80],
          backgroundColor: "rgba(255, 99, 132, 0.2)",
          borderColor: "rgba(255, 99, 132, 1)",
          pointBackgroundColor: "rgba(255, 99, 132, 1)",
        },
        {
          label: "Competitor B",
          data: [70, 85, 75, 80, 90],
          backgroundColor: "rgba(75, 192, 192, 0.2)",
          borderColor: "rgba(75, 192, 192, 1)",
          pointBackgroundColor: "rgba(75, 192, 192, 1)",
        },
      ],
    },
    options: {
      responsive: true,
      scales: {
        r: {
          angleLines: {
            display: false,
          },
          suggestedMin: 0,
          suggestedMax: 100,
        },
      },
    },
  })

  // Custom Report Generator
  const generateReportBtn = document.getElementById("generateReport")
  generateReportBtn.addEventListener("click", () => {
    const selectedMetrics = Array.from(document.querySelectorAll(".metric-selector input:checked")).map(
      (input) => input.value,
    )
    if (selectedMetrics.length > 0) {
      alert(`Generating report for: ${selectedMetrics.join(", ")}`)
      // Here you would typically make an API call to generate the report
    } else {
      alert("Please select at least one metric for the report.")
    }
  })

  // Animate feature items on scroll
  const featureItems = document.querySelectorAll(".feature-item")
  const observerOptions = {
    root: null,
    rootMargin: "0px",
    threshold: 0.1,
  }

  const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = 1
        entry.target.style.transform = "translateY(0)"
        observer.unobserve(entry.target)
      }
    })
  }, observerOptions)

  featureItems.forEach((item) => {
    item.style.opacity = 0
    item.style.transform = "translateY(20px)"
    observer.observe(item)
  })
})

