document.addEventListener("DOMContentLoaded", () => {
  // Smooth scrolling for navigation links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()

      document.querySelector(this.getAttribute("href")).scrollIntoView({
        behavior: "smooth",
      })
    })
  })

  // Simple form validation for the login and register pages
  const forms = document.querySelectorAll("form")
  forms.forEach((form) => {
    form.addEventListener("submit", function (e) {
      e.preventDefault()
      let isValid = true

      this.querySelectorAll("input[required]").forEach((input) => {
        if (!input.value) {
          isValid = false
          input.classList.add("error")
        } else {
          input.classList.remove("error")
        }
      })

      if (isValid) {
        alert("Form submitted successfully!")
        // Here you would typically send the form data to a server
      } else {
        alert("Please fill in all required fields.")
      }
    })
  })
})

