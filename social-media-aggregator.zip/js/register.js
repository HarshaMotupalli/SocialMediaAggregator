// Functionality specific to the register page
document.addEventListener("DOMContentLoaded", () => {
  console.log("Register page loaded")

  const registerForm = document.getElementById("register-form")

  registerForm.addEventListener("submit", (e) => {
    e.preventDefault()

    const name = document.getElementById("name").value
    const email = document.getElementById("email").value
    const password = document.getElementById("password").value
    const confirmPassword = document.getElementById("confirm-password").value

    if (password !== confirmPassword) {
      alert("Passwords do not match!")
      return
    }

    // Here you would typically send the registration data to a server
    console.log("Registration attempt:", { name, email, password })

    // Simulated registration success
    alert("Registration successful!")
  })
})

