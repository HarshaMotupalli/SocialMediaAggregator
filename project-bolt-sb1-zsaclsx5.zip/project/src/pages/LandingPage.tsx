import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, BarChart2, Calendar, Share } from 'lucide-react';

const LandingPage = () => {
  return (
    <div className="bg-gradient-to-b from-indigo-50 to-white">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="relative z-10 pb-8 sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
            <main className="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8 xl:mt-28">
              <div className="sm:text-center lg:text-left">
                <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
                  <span className="block">Manage your social media</span>
                  <span className="block text-indigo-600">presence effortlessly</span>
                </h1>
                <p className="mt-3 text-base text-gray-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                  Streamline your social media management with our all-in-one platform. Schedule posts, analyze performance, and grow your audience - all in one place.
                </p>
                <div className="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                  <div className="rounded-md shadow">
                    <Link
                      to="/home"
                      className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 md:py-4 md:text-lg md:px-10"
                    >
                      Get started
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </div>
                </div>
              </div>
            </main>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:text-center">
            <h2 className="text-base text-indigo-600 font-semibold tracking-wide uppercase">Features</h2>
            <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
              Everything you need to succeed
            </p>
            <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
              Our platform provides all the tools you need to manage your social media presence effectively.
            </p>
          </div>

          <div className="mt-10">
            <div className="space-y-10 md:space-y-0 md:grid md:grid-cols-3 md:gap-x-8 md:gap-y-10">
              {[
                {
                  name: 'Publish with ease',
                  description: 'Create and schedule posts across multiple platforms with our intuitive interface.',
                  icon: Share,
                  link: '/features/publish'
                },
                {
                  name: 'Advanced Analytics',
                  description: 'Track your performance with detailed insights and actionable recommendations.',
                  icon: BarChart2,
                  link: '/features/analyze'
                },
                {
                  name: 'Smart Scheduling',
                  description: 'Plan your content calendar and optimize posting times for maximum engagement.',
                  icon: Calendar,
                  link: '/features/schedule'
                }
              ].map((feature) => (
                <Link
                  key={feature.name}
                  to={feature.link}
                  className="relative p-6 border border-gray-200 rounded-lg hover:shadow-lg transition-shadow duration-300"
                >
                  <div>
                    <div className="absolute h-12 w-12 flex items-center justify-center rounded-md bg-indigo-500 text-white">
                      <feature.icon className="h-6 w-6" aria-hidden="true" />
                    </div>
                    <p className="ml-16 text-lg leading-6 font-medium text-gray-900">{feature.name}</p>
                  </div>
                  <p className="mt-2 ml-16 text-base text-gray-500">{feature.description}</p>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;