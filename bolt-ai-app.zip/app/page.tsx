"use client"

import  from "../js/common"

export default function SyntheticV0PageForDeployment() {
  return < />
}