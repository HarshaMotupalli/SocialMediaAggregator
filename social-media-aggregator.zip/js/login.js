// Functionality specific to the login page
document.addEventListener("DOMContentLoaded", () => {
  console.log("Login page loaded")

  const loginForm = document.getElementById("login-form")

  loginForm.addEventListener("submit", (e) => {
    e.preventDefault()

    const email = document.getElementById("email").value
    const password = document.getElementById("password").value

    // Here you would typically send the login data to a server
    console.log("Login attempt:", { email, password })

    // Simulated login success
    alert("Login successful!")
  })
})

