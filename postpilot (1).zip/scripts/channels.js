document.addEventListener("DOMContentLoaded", () => {
  // Add hover effect to channel items
  const channelItems = document.querySelectorAll(".channel-item")
  channelItems.forEach((item) => {
    item.addEventListener("mouseenter", () => {
      item.style.backgroundColor = "#e8e8e8"
    })
    item.addEventListener("mouseleave", () => {
      item.style.backgroundColor = "#f8f8f8"
    })
  })

  // Smooth scroll to channel integration section
  const integrationLink = document.createElement("a")
  integrationLink.href = "#channel-integration"
  integrationLink.textContent = "Learn how to connect your accounts"
  integrationLink.classList.add("integration-link")
  document.querySelector(".channel-grid").after(integrationLink)

  integrationLink.addEventListener("click", (e) => {
    e.preventDefault()
    document.querySelector("#channel-integration").scrollIntoView({
      behavior: "smooth",
    })
  })
})

