import { Chart } from "@/components/ui/chart"
document.addEventListener("DOMContentLoaded", () => {
  // Populate calendar
  const calendarGrid = document.querySelector(".calendar-grid")
  const daysInMonth = 31 // Assuming May 2023

  for (let i = 1; i <= daysInMonth; i++) {
    const dayElement = document.createElement("div")
    dayElement.classList.add("calendar-day")
    dayElement.textContent = i
    calendarGrid.appendChild(dayElement)

    dayElement.addEventListener("click", () => {
      dayElement.style.backgroundColor = "#007bff"
      dayElement.style.color = "#fff"
    })
  }

  // Animate feature items on scroll
  const featureItems = document.querySelectorAll(".feature-item")
  const observerOptions = {
    root: null,
    rootMargin: "0px",
    threshold: 0.1,
  }

  const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = 1
        entry.target.style.transform = "translateX(0)"
        observer.unobserve(entry.target)
      }
    })
  }, observerOptions)

  featureItems.forEach((item) => {
    item.style.opacity = 0
    item.style.transform = "translateX(-20px)"
    observer.observe(item)
  })

  // Create best time to post chart
  const bestTimeChart = document.querySelector(".best-time-chart")
  const ctx = bestTimeChart.getContext("2d")
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
  const data = [65, 59, 80, 81, 56, 55, 40]

  new Chart(ctx, {
    type: "bar",
    data: {
      labels: days,
      datasets: [
        {
          label: "Engagement Rate",
          data: data,
          backgroundColor: "rgba(0, 123, 255, 0.5)",
          borderColor: "rgba(0, 123, 255, 1)",
          borderWidth: 1,
        },
      ],
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  })

  // Make queue items draggable
  const queueItems = document.querySelectorAll(".queue-item")
  queueItems.forEach((item) => {
    item.setAttribute("draggable", true)
    item.addEventListener("dragstart", dragStart)
    item.addEventListener("dragend", dragEnd)
  })

  function dragStart(e) {
    e.target.style.opacity = "0.5"
  }

  function dragEnd(e) {
    e.target.style.opacity = "1"
  }
})

