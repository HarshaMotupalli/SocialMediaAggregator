document.addEventListener("DOMContentLoaded", () => {
  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()
      document.querySelector(this.getAttribute("href")).scrollIntoView({
        behavior: "smooth",
      })
    })
  })

  // Add active class to current nav item
  const currentPage = window.location.pathname.split("/").pop()
  document.querySelectorAll(".nav-links a").forEach((link) => {
    if (link.getAttribute("href") === currentPage) {
      link.classList.add("active")
    }
  })

  // Mobile menu toggle
  const mobileMenuToggle = document.createElement("button")
  mobileMenuToggle.classList.add("mobile-menu-toggle")
  mobileMenuToggle.innerHTML = "☰"
  document.querySelector("nav").appendChild(mobileMenuToggle)

  mobileMenuToggle.addEventListener("click", () => {
    document.querySelector(".nav-links").classList.toggle("show")
    document.querySelector(".auth-links").classList.toggle("show")
  })
})

