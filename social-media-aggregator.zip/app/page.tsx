"use client"

import  from "../js/register"

export default function SyntheticV0PageForDeployment() {
  return < />
}